import pro1 from "../Assets/project1img.png"



const ProjectCardData = [
    {
        imgsrc: pro1,
        title: "Picsite",
        text:"Picsite is a free stock photo website  that helps designers, bloggers, and everyone who is looking for visuals to find great photos  that can be downloaded and used.",
        view:"https://bhoomika-hm.github.io/picsite/",
        source:"https://github.com/Bhoomika-hm/picsite"
    },
    {
        imgsrc: pro1,
        title: "Photo Website",
        text:"k sfijm sfkdjmc sdifkjc",
        view:"https://bhoomika-hm.github.io/picsite/",
        source:"https://github.com/Bhoomika-hm/picsite"
    },
];
export default ProjectCardData;

